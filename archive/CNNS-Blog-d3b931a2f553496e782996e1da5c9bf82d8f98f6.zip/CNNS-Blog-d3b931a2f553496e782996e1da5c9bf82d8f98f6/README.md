

<img width="1607" alt="webui" src="https://github.com/Zaque-69/CNNSBlog/blob/main/readmepics/Untitled.png">


#WHAT IS CNNS ?:
  * CNNS is a top highschool in Ploiesti, Prahova, Romania;

#FEATURES :
  * 👥 Login and register systems; <br />
  * 💼 Posting information as a teacher or a student; <br />
  * 💬 Comment System for specific posts; <br />
  * ⚗️ Filter for posts ( only admin ) <br />
  * 🌎 Comunity page for everyone ! <br />
  
    
#OPTIONAL COMMAND IF YOU RUN IN LOCAL SQLITE DATABASE:
```
   > python manage.py createsuperuser ( your data )
```


<img width="1607" alt="webui" src="https://github.com/Zaque-69/CNNSBlog/blob/main/readmepics/Untitled2.png">


<img width="1607" alt="webui" src="https://github.com/Zaque-69/CNNSBlog/blob/main/readmepics/Untitled3.png">
